//
//  LindList.h
//  Algorithm
//
//  Created by mac on 2017/12/28.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LindList : NSObject

/**
 在链表尾部添加对象

 @param obj 要添加的对象
 */
-(void)addObjToFooter:(id)obj;

/**
 在链表头部添加对象
 
 @param obj 要添加的对象
 */
-(void)addObjToHeader:(id)obj;

/**
 删除第一个对象
 */
-(void)removeFirstObj;

/**
 删除最后一个对象
 */
-(void)removeLastObj;

/**
 遍历链表

 @param resultCallBack 回调
 */
-(void)traverseList:(void(^)(id obj))resultCallBack;

/**
 获取第一个对象

 @return 对象
 */
-(id)firstObj;

/**
 获取最后一个对象

 @return 对象
 */
-(id)lastObj;

/**
 判断链表是否为空

 @return 是否为空
 */
-(BOOL)isEmpty;
@end
