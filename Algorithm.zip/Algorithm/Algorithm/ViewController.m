//
//  ViewController.m
//  Algorithm
//
//  Created by mac on 2017/12/27.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "ViewController.h"
#import "AlgorithmMethods.h"
#import "Stack.h"
#import "LindList.h"
#import "Sort.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //两个数的最大公约数
    int gcd = [AlgorithmMethods getGCDWithP:108 q:8];
    NSLog(@"108和8的最大公约数%d",gcd);
    //多个数的最大公约数
    gcd = [AlgorithmMethods getGCD:108,48,8];
    NSLog(@"108、48、8的最大公约数%d",gcd);
    
    //升序数组中查找一个数的索引（二分查找法）
    NSMutableArray *numArr = [[NSMutableArray alloc] init];
    for (int i = 0; i < 10000; i++) {
        [numArr addObject:@(i)];
    }
    int index = [AlgorithmMethods binarySearch:99 in:numArr];
    NSLog(@"99在numArr的索引:%d",index);
    
    //双栈算术表达式求值法
    NSString *expressionStr = @"(1+((2+3)*(4*5)))";
    double value = [AlgorithmMethods getValueFromExpressionByDoubleStack:expressionStr];
    NSLog(@"(1+((2+3)*(4*5))) = %f",value);
    
    //链表
    [self useCaseOfLinkList];
    
    //从命令行接收一个整数N作为参数并生成一系列0到N-1之间的随机整数。通过实验验证产生第一个重复的随机整数之前生成的整数数量的平方为πN/2
    [self useCaseOfRepetitionRand];
    
    NSMutableArray *selectionSortArr = [[NSMutableArray alloc] init];
    for (int i = 0; i < 100; i++) {
        int num = arc4random()%1000;
        [selectionSortArr addObject:@(num)];
    }
    NSArray *sortArr = [Sort selectionSort:selectionSortArr];
    
    sortArr = [Sort insertionSort:selectionSortArr];
    sortArr = [Sort hillSort:selectionSortArr];
    NSLog(@"选择排序后的数组：%@",sortArr);
    NSArray *sortArr1 = @[@1,@4,@7,@9,@12,@2,@5,@6,@9,@20];
    sortArr = [Sort autochthonousMergeSort:sortArr1];
    NSLog(@"选择排序后的数组：%@",sortArr);
    //快速排序案例
    NSMutableArray *quitSortArr = [[NSMutableArray alloc] init];
    for (int i = 0; i < 100; i++) {
        int num = arc4random()%1000;
        [quitSortArr addObject:@(num)];
    }
    
    [Sort quickSort:quitSortArr lo:0 hi:(int)quitSortArr.count-1];
    NSLog(@"快速排序后的数组：%@",quitSortArr);
}
-(void)useCaseOfLinkList{
    LindList *list = [[LindList alloc] init];
    for (int i = 0; i < 10; i++) {
        [list addObjToFooter:[NSString stringWithFormat:@"第%d个对象",i]];
    }
    [list removeFirstObj];
    [list traverseList:^(id obj) {
        NSLog(@"%@",obj);
    }];
    
    LindList *list1 = [[LindList alloc] init];
    for (int i = 0; i < 10; i++) {
        [list1 addObjToHeader:[NSString stringWithFormat:@"第%d个对象",i]];
    }
    [list1 removeLastObj];
    [list1 traverseList:^(id obj) {
        NSLog(@"%@",obj);
    }];
}
-(void)useCaseOfRepetitionRand{
    int totalCount = 0;
    int count = 0;
    float verify = 0;
    for (int N = 1000; N < 100000; N=N+100) {
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        BOOL isBreak = NO;
        for (int i = 0; i < N*10; i++) {
            
            int rand = arc4random() % N;
            for (NSNumber *num in arr) {
                if (num.intValue == rand) {
                    isBreak = YES;
                    break;
                }
            }
            if (isBreak) {
                break;
            }
            [arr addObject:@(rand)];
        }
        
        count++;
        totalCount += arr.count;
        verify += sqrtf(M_PI * N / 2.0);
    }
    NSLog(@"产生第一个重复的随机整数之前生成的整数数量与πN/2的比为%f",(float)totalCount/verify);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
