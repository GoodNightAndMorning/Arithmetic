//
//  AlgorithmMethods.h
//  Algorithm
//
//  Created by mac on 2017/12/27.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlgorithmMethods : NSObject

/**
 求两个整数的最大公约数（欧几里得算法）

 @param p p
 @param q q
 @return 最大公约数
 */
+(int)getGCDWithP:(int)p q:(int)q;

/**
 求多个整数的最大公约数

 @param num 整数
 @return 最大公约数
 */
+(int)getGCD:(int)num,...;
/**
 二分查找法：查找一个数在升序数组中的位置
 
 @param num 要查找的数
 @param arr 数组
 @return 索引
 */
+(int)binarySearch:(int)num in:(NSArray *)arr;

/**
 双栈算术表达式求值法

 @param expression 表达式
 @return 值
 */
+(double)getValueFromExpressionByDoubleStack:(NSString *)expression;


@end
