//
//  Sort.m
//  Algorithm
//
//  Created by mac on 2018/1/3.
//  Copyright © 2018年 mac. All rights reserved.
//

#import "Sort.h"

@implementation Sort
/**
 选择排序 升序
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)selectionSort:(NSArray *)arr{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:arr copyItems:YES];
    int exchCount = 0;
    int compareCount = 0;
    for (int i = 0; i < array.count; i++) {
        int index = i;
        for (int j = i+1; j < array.count; j++) {
            compareCount++;
            if ([array[index] intValue] > [array[j] intValue]) {
                index = j;
            }
        }
        NSNumber *tmp = array[i];
        array[i] = array[index];
        array[index] = tmp;
        
        exchCount++;
    }
    NSLog(@"100个随机数选择排序比较次数：%d",compareCount);
    NSLog(@"100个随机数选择排序交换次数：%d",exchCount);
    return array;
}
/**
 插入排序 升序
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)insertionSort:(NSArray *)arr{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:arr copyItems:YES];
    int exchCount = 0;
    int compareCount = 0;
    for (int i = 1; i < array.count; i++) {
        for (int j = i; j > 0; j--) {
            compareCount++;
            if ([array[j] intValue] < [array[j-1] intValue]) {
                NSNumber *tmp = array[j];
                array[j] = array[j-1];
                array[j-1] = tmp;
                exchCount++;
            }else{
                break;
            }
        }
    }
    NSLog(@"100个随机数插入排序比较次数：%d",compareCount);
    NSLog(@"100个随机数插入排序交换次数：%d",exchCount);
    return array;
}
/**
 希尔排序
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)hillSort:(NSArray *)arr{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:arr copyItems:YES];
    int exchCount = 0;
    int compareCount = 0;
    int N = (int)array.count;
    int h = 1;
    while (h < N/3) {
        h = h*3 + 1;
    }
    while (h >= 1) {
        for (int i = h; i < N; i++) {
            for (int j = i; j >= h; j-=h) {
                compareCount++;
                if ([array[j] intValue] < [array[j-h] intValue]) {
                    NSNumber *tmp = array[j];
                    array[j] = array[j-h];
                    array[j-h] = tmp;
                    exchCount++;
                }else{
                    break;
                }
            }
        }
        h = h/3;
    }
    NSLog(@"100个随机数希尔排序比较次数：%d",compareCount);
    NSLog(@"100个随机数希尔排序交换次数：%d",exchCount);
    return array;
}
/**
 原地归并排序
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)autochthonousMergeSort:(NSArray *)arr{
    NSMutableArray *array = [[NSMutableArray alloc] initWithArray:arr copyItems:YES];
    int compareCount = 0;
    
    int lo = 0;
    int hi = (int)array.count - 1;
    int mid = hi / 2;
    
    int i = lo;
    int j = mid + 1;
    
    NSMutableArray *tmpArr = [[NSMutableArray alloc] init];
    
    for (int k = lo; k <= hi; k++) {
        compareCount++;
        if (i > mid) {
            [tmpArr addObject:array[j++]];
        }else if (j > hi){
            [tmpArr addObject:array[i++]];
        }else if ([array[i] intValue] < [array[j] intValue]){
            [tmpArr addObject:array[i++]];
        }else{
            [tmpArr addObject:array[j++]];
        }
    }
    
    NSLog(@"10个元素数组原地归并排序比较次数：%d",compareCount);
    return tmpArr;
}

static int exch = 0;
static int compare = 0;
/**
 快速排序
 
 @param arr 要排序的数组
 @param lo 起始下标
 @param hi ；末尾下标
 */

+(void)quickSort:(NSMutableArray *)arr lo:(int)lo hi:(int)hi{
    /*
    if (hi <= lo) {
        NSLog(@"100个随机数希尔排序比较次数：%d",compare);
        NSLog(@"100个随机数希尔排序交换次数：%d",exch);
        return;
    }
     */
    //小数组时，切换到插入排序
    //-------------------------------------
    int M = 10;//5~15之间
    if (hi <= lo + M) {
        NSLog(@"100个随机数快速排序比较次数：%d",compare);
        NSLog(@"100个随机数快速排序交换次数：%d",exch);
        [self p_insertionSort:arr lo:lo hi:hi];
        return;
    }
    //-------------------------------------
    
    
    int j = [self p_partition:arr lo:lo hi:hi];
    [self quickSort:arr lo:lo hi:j-1];
    [self quickSort:arr lo:j+1 hi:hi];
}
+(int)p_partition:(NSMutableArray *)arr lo:(int)lo hi:(int)hi{
    int i = lo;
    int j = hi+1;
    int v = [arr[lo] intValue];
    
    while (YES) {
        while ([arr[++i] intValue] < v) {
            compare++;
            if (i == hi) {
                break;
            }
        }
        while ([arr[--j] intValue] > v) {
            compare++;
            if (j == lo) {
                break;
            }
        }
        if (i >= j) {
            compare++;
            break;
        }
        
        NSNumber *tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
        
        exch++;
    }
    NSNumber *tmp = arr[lo];
    arr[lo] = arr[j];
    arr[j] = tmp;
    exch++;
    return j;
}
+(void)p_insertionSort:(NSMutableArray *)array  lo:(int)lo hi:(int)hi{
    int exchCount = 0;
    int compareCount = 0;
    for (int i = lo+1; i < hi+1; i++) {
        for (int j = i; j > 0; j--) {
            compareCount++;
            if ([array[j] intValue] < [array[j-1] intValue]) {
                NSNumber *tmp = array[j];
                array[j] = array[j-1];
                array[j-1] = tmp;
                exchCount++;
            }else{
                break;
            }
        }
    }
    NSLog(@"100个随机数插入排序比较次数：%d",compareCount);
    NSLog(@"100个随机数插入排序交换次数：%d",exchCount);
}
@end
