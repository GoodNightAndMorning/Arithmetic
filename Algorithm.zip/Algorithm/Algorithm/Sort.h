//
//  Sort.h
//  Algorithm
//
//  Created by mac on 2018/1/3.
//  Copyright © 2018年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 任意算法的比较次数：lgN! ~ NlgN
 */
@interface Sort : NSObject
/**
 选择排序 升序
 对于长度为N的数组，选择排序需要大约N²/2次比较和N次交换
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)selectionSort:(NSArray *)arr;

/**
 插入排序 升序
 插入排序需要的交换操作和数组中倒置的数量相同，需要的比较次数大于等于倒置的数量，小于等于倒置的数量加上数组的大小再减一
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)insertionSort:(NSArray *)arr;

/**
 希尔排序
 使用递增序列 1，4，13，40，121，264...的希尔排序所需的比较次数不会超出N的若干倍乘以递增序列的长度。
 
 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)hillSort:(NSArray *)arr;

/**
 原地归并排序

 @param arr 要排序的数组
 @return 已经排序的数组
 */
+(NSMutableArray *)autochthonousMergeSort:(NSArray *)arr;

/**
 快速排序
 将长度为N的无重复数组排序，快速排序平均需要 ~2NlnN次比较（以及1/6的交换）
 快速排序最多需要约N²/2次比较，但随即打乱数组能够预防这种情况
 
 @param arr 要排序的数组
 @param lo 起始下标
 @param hi ；末尾下标
 */
+(void)quickSort:(NSMutableArray *)arr lo:(int)lo hi:(int)hi;
@end
