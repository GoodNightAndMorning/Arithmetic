//
//  AlgorithmMethods.m
//  Algorithm
//
//  Created by mac on 2017/12/27.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "AlgorithmMethods.h"
#import "Stack.h"
@implementation AlgorithmMethods

/**
 求两个整数的最大公约数（欧几里得算法）
 
 @param p p
 @param q q
 @return 最大公约数
 */
+(int)getGCDWithP:(int)p q:(int)q{
    if (q == 0) {
        return p;
    }else{
        int r = p % q;
        return [self getGCDWithP:q q:r];
    }
}

/**
 求多个整数的最大公约数
 
 @param num 整数
 @return 最大公约数
 */
+(int)getGCD:(int)num,...{
    va_list argList;
    
    va_start(argList, num);
    
    int arg1 = num;
    int arg2 = va_arg(argList, int);
    while (arg2) {
        arg1 = [self getGCDWithP:arg1 q:arg2];
        arg2 = va_arg(argList, int);
    }
    va_end(argList);

    return arg1;
}

/**
 二分查找法：查找一个数在升序数组中的位置

 @param num 要查找的数
 @param arr 数组
 @return 索引
 */
+(int)binarySearch:(int)num in:(NSArray *)arr{
    int lo = 0;
    int hi = (int)arr.count - 1;
    int count = 0;
    while (lo <= hi) {
        count++;
        int mid = (lo + hi) / 2;
        if ([arr[mid] intValue] < num) {
            lo = mid + 1;
        }else if ([arr[mid] intValue] > num){
            hi = mid - 1;
        }else{
            NSLog(@"计算次数：%d",count);
            return mid;
        }
    }
    return -1;
}
/**
 双栈算术表达式求值法
 
 @param expression 表达式
 @return 值
 */
+(double)getValueFromExpressionByDoubleStack:(NSString *)expression{
    NSString *expressionStr = expression;
    Stack *vals = [[Stack alloc] init];
    Stack *opls = [[Stack alloc] init];
    NSString *newValue = @"";
    for (int i = 0; i < expressionStr.length; i++) {
        NSString *str = [expressionStr substringWithRange:NSMakeRange(i, 1)];
        if ([str isEqualToString:@"("]) {
            
        }else if ([@"+-*/" containsString:str]){
            [opls push:str];
        }else if ([str isEqualToString:@")"]){
            NSString *oplStr = [opls popObj];
            NSString *valStr = [vals popObj];
            if ([oplStr isEqualToString:@"+"]) {
                newValue = [NSString stringWithFormat:@"%lf",[[vals popObj] doubleValue] + [valStr doubleValue]];
            }else if ([oplStr isEqualToString:@"-"]){
                newValue = [NSString stringWithFormat:@"%lf",[[vals popObj] doubleValue] - [valStr doubleValue]];
            }else if ([oplStr isEqualToString:@"*"]){
                newValue = [NSString stringWithFormat:@"%lf",[[vals popObj] doubleValue] * [valStr doubleValue]];
            }else if ([oplStr isEqualToString:@"/"]){
                newValue = [NSString stringWithFormat:@"%lf",[[vals popObj] doubleValue] / [valStr doubleValue]];
            }
            [vals push:newValue];
        }else{
            [vals push:str];
        }
    }
    return newValue.doubleValue;
}

@end
