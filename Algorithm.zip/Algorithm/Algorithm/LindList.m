//
//  LindList.m
//  Algorithm
//
//  Created by mac on 2017/12/28.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "LindList.h"
//#import "Node.h"

@interface Node : NSObject
@property(nonatomic,strong)id obj;
@property(nonatomic,strong)Node *nextNode;
@property(nonatomic,strong)Node *previousNode;
@end
@implementation Node

@end

@interface LindList()
@property(nonatomic,strong)Node *firstNode;
@property(nonatomic,strong)Node *lastNode;
@end

@implementation LindList
-(void)addObjToFooter:(id)obj{
    Node *node = [[Node alloc] init];
    node.obj = obj;
    node.previousNode = self.lastNode;
    
    self.lastNode.nextNode = node;
    self.lastNode = node;

    if (!self.firstNode) {
        self.firstNode = node;
    }
}
-(void)addObjToHeader:(id)obj{

    Node *node = [[Node alloc] init];
    node.obj = obj;
    node.nextNode = self.firstNode;
    
    self.firstNode.previousNode = node;
    
    self.firstNode = node;
    
    if (!self.lastNode) {
        self.lastNode = node;
    }
}
-(void)removeLastObj{
    Node *node = self.lastNode.previousNode;
    self.lastNode = nil;
    node.nextNode = nil;
    self.lastNode = node;
}
-(void)removeFirstObj{
    Node *node = self.firstNode.nextNode;
    self.firstNode = nil;
    self.firstNode = node;
}
-(void)traverseList:(void (^)(id))resultCallBack{
    Node *node = self.firstNode;
    while (node) {
        resultCallBack(node.obj);
        node = node.nextNode;
    }
}
-(id)firstObj{
    return self.firstNode.obj;
}
-(id)lastObj{
    return self.lastNode.obj;
}
-(BOOL)isEmpty{
    if (self.firstNode) {
        return NO;
    }else{
        return YES;
    }
}
@end
